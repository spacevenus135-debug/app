package com.stopclock

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.*
import kotlin.concurrent.thread

// ─────────────────────────────────────────────
//  States
// ─────────────────────────────────────────────
enum class GameState { IDLE, RUNNING, DONE }

class MainActivity : AppCompatActivity() {

    // ── UI refs ──────────────────────────────
    private lateinit var displayText: TextView
    private lateinit var unitText: TextView
    private lateinit var statusLabel: TextView
    private lateinit var mainButton: Button
    private lateinit var clockCircle: View
    private lateinit var topStrip: View

    // ── State ────────────────────────────────
    private var gameState = GameState.IDLE
    private var startTime  = 0L
    private val handler    = Handler(Looper.getMainLooper())

    // ── Colors ───────────────────────────────
    private val colorAccent  = Color.parseColor("#c8fb57")
    private val colorGood    = Color.parseColor("#57fbaa")
    private val colorDanger  = Color.parseColor("#ff4d6d")
    private val colorSurface = Color.parseColor("#111118")
    private val colorBg      = Color.parseColor("#0a0a0f")
    private val colorMuted   = Color.parseColor("#55556a")
    private val colorText    = Color.parseColor("#e8e8f0")

    // ── Tick runnable ────────────────────────
    private val tickRunnable = object : Runnable {
        override fun run() {
            val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
            displayText.text = "%.2f".format(elapsed)
            handler.postDelayed(this, 16) // ~60fps
        }
    }

    // ─────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        displayText  = findViewById(R.id.displayText)
        unitText     = findViewById(R.id.unitText)
        statusLabel  = findViewById(R.id.statusLabel)
        mainButton   = findViewById(R.id.mainButton)
        clockCircle  = findViewById(R.id.clockCircle)
        topStrip     = findViewById(R.id.topStrip)

        mainButton.setOnClickListener { handleButton() }
        applyIdleState()
    }

    // ─────────────────────────────────────────
    private fun handleButton() {
        when (gameState) {
            GameState.IDLE, GameState.DONE -> startRound()
            GameState.RUNNING              -> stopRound()
        }
    }

    // ─────────────────────────────────────────
    private fun startRound() {
        gameState = GameState.RUNNING
        startTime = System.currentTimeMillis()

        // UI
        statusLabel.text = "الساعة شغّالة — أوقفها متى تريد"
        mainButton.text  = "⏹ أوقف"
        mainButton.setBackgroundColor(colorDanger)
        mainButton.setTextColor(Color.WHITE)
        topStrip.setBackgroundColor(colorGood)
        displayText.setTextColor(colorText)

        // pulse animation on button
        pulseButton(true)

        // start tick
        handler.post(tickRunnable)

        // sound: طيط طيط
        thread { playDeviceBeep(1400, 100, 0) }
        thread { playDeviceBeep(1400, 140, 180) }
    }

    // ─────────────────────────────────────────
    private fun stopRound() {
        handler.removeCallbacks(tickRunnable)
        gameState = GameState.DONE

        val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
        val formatted = "%.2f".format(elapsed)

        // UI
        displayText.text  = formatted
        displayText.setTextColor(colorDanger)
        statusLabel.text  = "الوقت — اسأل من حولك!"
        mainButton.text   = "▶ جولة جديدة"
        mainButton.setBackgroundColor(colorSurface)
        mainButton.setTextColor(colorText)
        topStrip.setBackgroundColor(colorDanger)

        pulseButton(false)

        // sound: طووووط
        thread { playDeviceBeep(520, 380, 0) }
    }

    // ─────────────────────────────────────────
    private fun applyIdleState() {
        gameState = GameState.IDLE
        displayText.text  = "0.00"
        displayText.setTextColor(colorText)
        statusLabel.text  = "اضغط ابدأ"
        mainButton.text   = "▶ ابدأ"
        mainButton.setBackgroundColor(colorAccent)
        mainButton.setTextColor(colorBg)
        topStrip.setBackgroundColor(colorAccent)
        pulseButton(false)
    }

    // ─────────────────────────────────────────
    //  Button pulse animator
    // ─────────────────────────────────────────
    private var pulseAnimator: ObjectAnimator? = null

    private fun pulseButton(on: Boolean) {
        pulseAnimator?.cancel()
        mainButton.alpha = 1f
        if (!on) return
        pulseAnimator = ObjectAnimator.ofFloat(mainButton, "alpha", 1f, 0.65f).apply {
            duration       = 700
            repeatMode     = ValueAnimator.REVERSE
            repeatCount    = ValueAnimator.INFINITE
            interpolator   = AccelerateDecelerateInterpolator()
            start()
        }
    }

    // ─────────────────────────────────────────
    //  Audio: real device-style beep
    //  Sine fundamental + 3rd harmonic + click transient
    //  All synthesized via AudioTrack PCM
    // ─────────────────────────────────────────
    private fun playDeviceBeep(freqHz: Int, durationMs: Int, delayMs: Long) {
        if (delayMs > 0) Thread.sleep(delayMs)

        val sampleRate   = 44100
        val totalSamples = (sampleRate * durationMs / 1000.0).toInt()
        val buffer       = ShortArray(totalSamples)

        val fundamental  = freqHz.toDouble()
        val harmonic3    = fundamental * 3.0
        val attackSamples  = (sampleRate * 0.010).toInt()   // 10ms attack
        val releaseSamples = (sampleRate * 0.018).toInt()   // 18ms release
        val clickSamples   = (sampleRate * 0.012).toInt()   // 12ms click transient

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate

            // envelope
            val env = when {
                i < attackSamples  -> i.toDouble() / attackSamples
                i > totalSamples - releaseSamples -> {
                    val remaining = totalSamples - i
                    remaining.toDouble() / releaseSamples
                }
                else -> 1.0
            }

            // click transient (square burst at 3x freq, only first 12ms)
            val clickAmp = if (i < clickSamples) {
                0.6 * (1.0 - i.toDouble() / clickSamples) *
                        sign(sin(2 * PI * harmonic3 * t))
            } else 0.0

            // main sine
            val mainSine = 0.55 * sin(2 * PI * fundamental * t) * env

            // 3rd harmonic (thin, gives "electronic" texture)
            val harmSine = 0.08 * sin(2 * PI * harmonic3 * t) * env

            val sample = (mainSine + harmSine + clickAmp).coerceIn(-1.0, 1.0)
            buffer[i]  = (sample * Short.MAX_VALUE).toInt().toShort()
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(buffer, 0, buffer.size)
        track.play()

        // release after playback
        Thread.sleep(durationMs.toLong() + 50)
        track.stop()
        track.release()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        pulseAnimator?.cancel()
    }
}
